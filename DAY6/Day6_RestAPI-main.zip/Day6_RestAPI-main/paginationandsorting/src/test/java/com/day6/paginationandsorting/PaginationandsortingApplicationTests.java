package com.day6.paginationandsorting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaginationandsortingApplicationTests {

	@Test
	void contextLoads() {
	}

}
